import sys

N = int(input("Nombre de produits dans le comparateur"))  #
P = input("Produit recherché")  #

prix_minimum = sys.maxsize  # Initialisation du prix minimum à une valeur très grande

for _ in range(N):
    produit, prix = input("produit et prix").split()
    prix = int(prix)

    if produit == P:
        prix_minimum = min(prix_minimum, prix)

print("le prix minimal est:",prix_minimum)