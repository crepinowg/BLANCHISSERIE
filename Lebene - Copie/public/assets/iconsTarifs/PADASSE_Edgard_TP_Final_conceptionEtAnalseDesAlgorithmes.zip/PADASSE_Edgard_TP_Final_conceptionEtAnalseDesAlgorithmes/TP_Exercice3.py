from itertools import permutations

def trouver_repartition_optimale(mot1, mot2, somme):
    chiffres = set(mot1 + mot2)  # Obtenir tous les chiffres uniques présents dans les deux mots
    chiffres = sorted(chiffres)  # Trier les chiffres dans l'ordre croissant

    for permutation in permutations(range(1, 10), len(chiffres)):
        correspondance = dict(zip(chiffres, permutation))  # Associer chaque lettre à un chiffre

        nombre1 = int("".join(str(correspondance[lettre]) for lettre in mot1))
        nombre2 = int("".join(str(correspondance[lettre]) for lettre in mot2))

        if nombre1 + nombre2 == somme:
            return nombre1

# Lecture des données d'entrée
mot1 = input("premier mot").strip()
mot2 = input("deuxième mot").strip()
somme = int(input("somme"))

# Appel de la fonction pour trouver la répartition optimale
repartition_optimale = trouver_repartition_optimale(mot1, mot2, somme)

# Affichage du résultat
print(repartition_optimale)

