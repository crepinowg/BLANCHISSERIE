chaine = "Bonjour tout le monde"
sous_chaine = "tout"
position = 3
longueur = 5
mot = "RADAR"

# Vérifier l'existence d'une sous-chaînedef verifier_sous_chaine(chaine, sous_chaine):
#     return sous_chaine in chaine


def verifier_sous_chaine(chaine, sous_chaine):
    return sous_chaine in chaine

if verifier_sous_chaine(chaine, sous_chaine):
    print("La sous-chaîne existe dans la chaîne.")
else:
    print("La sous-chaîne n'existe pas dans la chaîne.")

# Supprimer une partie de la chaîne


def supprimer_partie(chaine, position, longueur):
    return chaine[:position] + chaine[position + longueur:]

chaine_modifiee = supprimer_partie(chaine, position, longueur)
print("Chaîne modifiée :", chaine_modifiee)

# Vérifier si un mot est un palindrome




def est_palindrome(mot):
    return mot == mot[::-1]

if est_palindrome(mot):
    print("Le mot est un palindrome.")
else:
    print("Le mot n'est pas un palindrome.")
